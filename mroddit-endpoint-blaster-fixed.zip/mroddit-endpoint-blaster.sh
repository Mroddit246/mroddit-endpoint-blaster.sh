#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${GREEN}[*] Starting mroddit-endpoint-blaster...${NC}"

read -p "Enter the target domain (e.g. example.com): " DOMAIN

# Create output directory
OUTPUT_DIR="outputs/$DOMAIN"
mkdir -p "$OUTPUT_DIR"

# Save the domain
echo "$DOMAIN" > "$OUTPUT_DIR/target.txt"

# Ensure tools are installed or install them
install_tool() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}[-] $1 not found. Installing...${NC}"
        if [[ $1 == "gauplus" ]]; then
            go install github.com/bp0lr/gauplus@latest
        elif [[ $1 == "waybackurls" ]]; then
            go install github.com/tomnomnom/waybackurls@latest
        elif [[ $1 == "waymore" ]]; then
            git clone https://github.com/xnl-h4ck3r/waymore.git tools/waymore &> /dev/null
        elif [[ $1 == "katana" ]]; then
            go install github.com/projectdiscovery/katana/cmd/katana@latest
        elif [[ $1 == "hakrawler" ]]; then
            go install github.com/hakluke/hakrawler@latest
        elif [[ $1 == "paramspider" ]]; then
            pip3 install paramspider &> /dev/null
        elif [[ $1 == "arjun" ]]; then
            git clone https://github.com/s0md3v/Arjun.git tools/arjun &> /dev/null
        elif [[ $1 == "linkfinder" ]]; then
            pip3 install git+https://github.com/GerbenJavado/LinkFinder.git &> /dev/null
        fi
    else
        echo -e "${GREEN}[+] $1 is already installed.${NC}"
    fi
}

TOOLS=("gauplus" "waybackurls" "katana" "hakrawler")
for TOOL in "${TOOLS[@]}"; do
    install_tool "$TOOL"
done

# Run tools and collect output
echo -e "${GREEN}[*] Running gauplus...${NC}"
gauplus -o "$OUTPUT_DIR/gauplus.txt" -t 20 -random-agent -subs "$DOMAIN" 2>/dev/null

echo -e "${GREEN}[*] Running waybackurls...${NC}"
echo "$DOMAIN" | waybackurls > "$OUTPUT_DIR/wayback.txt" 2>/dev/null

echo -e "${GREEN}[*] Running katana...${NC}"
katana -u "https://$DOMAIN" -o "$OUTPUT_DIR/katana.txt" 2>/dev/null

echo -e "${GREEN}[*] Running hakrawler...${NC}"
echo "$DOMAIN" | hakrawler > "$OUTPUT_DIR/hakrawler.txt" 2>/dev/null

# Combine and sort unique endpoints
cat "$OUTPUT_DIR"/*.txt | sort -u > "$OUTPUT_DIR/all-endpoints.txt"

echo -e "${GREEN}[✔] All tasks completed.${NC}"
echo -e "${GREEN}[✔] Output saved to: $OUTPUT_DIR${NC}"
